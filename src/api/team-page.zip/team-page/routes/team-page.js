'use strict';

/**
 * team-page router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::team-page.team-page');
